const express = require('express');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

// Pump.fun Proxy
app.get('/api/pumpfun', async (req, res) => {
  try {
    const response = await fetch('https://api.pump.fun/api/tokens');
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Fehler bei Pump.fun' });
  }
});

// Dexscreener Proxy
app.get('/api/dexscreener', async (req, res) => {
  try {
    const response = await fetch('https://api.dexscreener.com/latest/dex/pairs/solana');
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Fehler bei Dexscreener' });
  }
});

// GMGN Proxy
app.get('/api/gmgn', async (req, res) => {
  try {
    const response = await fetch('https://gmgn.ai/api/tokens');
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Fehler bei GMGN' });
  }
});

app.listen(PORT, () => {
  console.log(`Proxy läuft auf Port ${PORT}`);
});